package com.example.backend.jwtModule.Dto;


public class ResponceLogin {
    private String email;
    private String nom;
    private String prenom;
    private String rol;
    private String token;

    public ResponceLogin(String email,String nom,String prenom,String rol,String token){
        this.email=email;
        this.nom=nom;
        this.prenom=prenom;
        this.rol=rol;
        this.token=token;
    }
    /**
     * @return String return the username
     */
    

    /**
     * @return String return the rol
     */
    public String getRol() {
        return rol;
    }

    /**
     * @param rol the rol to set
     */
    public void setRol(String rol) {
        this.rol = rol;
    }

    /**
     * @return String return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token the token to set
     */
    public void setToken(String token) {
        this.token = token;
    }


    /**
     * @return String return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return String return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * @return String return the prenom
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     * @param prenom the prenom to set
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

}
